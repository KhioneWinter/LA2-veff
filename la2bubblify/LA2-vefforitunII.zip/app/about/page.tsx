
const URL = "http://localhost:3500";

export default async function AboutBubble() {
  // Some company explenations
  return (
    <div className="p-2">
        <h1 className="font-bold">About us!</h1>
        <p>We are a small company that specialize in bubble production!</p>
        
        <hr/>

        <p>We have now made many different types that anyone will find fun to use</p>
        <p>Also feel free to conntact us at somecoolemail@bubbles.coom</p>
    </div>
  );
}
