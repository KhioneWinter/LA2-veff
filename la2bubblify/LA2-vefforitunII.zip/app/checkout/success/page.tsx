'use client'


import {useCart} from "../../_components/CartContext";
import {useRouter} from "next/navigation";
import { useEffect } from "react";


export default function currentOrder() {
    // Success if the user was happy with the result and everything went through without error
    const router = useRouter();
    const {clearCart} = useCart();

    async function ConformationHome() {
        router.push("/");
    }

    useEffect(() => {
        clearCart();
    }, []);

    return (
        <div className="p-2">
            <h1 className="font-bold">Successful order confirmation! 🎊</h1>
            <p className="pb-5">We will let you know when your bubbles are on their way!</p>
            <button onClick={ConformationHome} className="bg-blue-400 active:bg-blue-600 p-2">Back to homepage</button>
        </div>
    );
}
